function validateForm() {
   var name = document.forms["myForm"]["name"].value;
   var email = document.forms["myForm"]["email"].value;
   var number = document.forms["myForm"]["number"].value;

   var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

   var numberRegex = /^\d{10}$/;

   if (name.trim() === '' || email.trim() === '' || number.trim() === '' || message.trim() === '') {
      alert('All fields must be filled out');
      return false;
   }
   if (!emailRegex.test(email)) {
      alert('Invalid email address');
      return false;
   }
   if (!numberRegex.test(number)) {
      alert('Invalid phone number');
      return false;
   }
   else {
      alert('Form submitted successfully');
   }
}